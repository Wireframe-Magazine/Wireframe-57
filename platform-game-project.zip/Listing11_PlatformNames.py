
platformNames = ['platform_rock_1', 'platform_rock_2', 'platform_rock_3', 'platform_rock_4',
                 'platform_grass_1', 'platform_grass_2', 'platform_grass_3', 'platform_grass_4',
                 'platform_tree_1', 'platform_tree_2', 'platform_tree_3', 'platform_tree_4', 'platform_tree_5',
                 'platform_cloud_1', 'platform_cloud_2', 'platform_cloud_3']


