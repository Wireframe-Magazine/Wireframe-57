
enemyNames = [['green_worm_right', 'green_worm_left'],
              ['red_worm_right', 'red_worm_left'],
              ['bee_1_right', 'bee_1_left',
               'bee_2_right', 'bee_2_left',
               'bee_3_right', 'bee_3_left']]

